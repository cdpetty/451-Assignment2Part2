# Running Our Model

It is easy to test our model.  All you need to do is run the program “determine.py” with python 2.7.  

You can either provide the filenames as command line parameters, or if you run the program with no parameters, it will prompt you for a filename. It then automatically scores and outputs the result. The files should be a single line hex string.

For example:

python determine.py match1.txt

where hexstring is a single line hex string.
